La idea para el proyecto final es hacer un E-Commerce sobre una tienda online de vinilos.

Para esta entrega preliminar me centré mucho en cumplir con las consignas de los desafíos. Por ejemplo en el futuro, de ser posible,
me gustaria que la ruta home "/" no sea el ItemListContainer con todo el catálogo.
Por otro lado no estaba seguro si debía dejar el setTimeout para retrasar la promise 2 segundos; per decidí dejarlo
y aprovechar para hacer un conditional rendering como el visto en clase.

En el proyecto instalé SCSS y AXIOS
