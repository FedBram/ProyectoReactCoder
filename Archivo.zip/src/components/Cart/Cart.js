const Cart = () => {
    return (
        <h1>COMPONENTE CART</h1>
    )
}


export default Cart